<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Apple564</title>
<link rel="stylesheet" type="text/css" href="Apple564.css"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
    
</head>
<body >
<h4 align="right"></h4> <i class="fa fa-caret-down"></i>
     <h4 align="right">    <button type="button" class="btn btn-default btn-sm">
          <span class="glyphicon glyphicon-log-out"></span><a href="home.php"> Log out</a>
        </button></h4>
<center>
<div>
<figure>
<b><figcaption>Apple iPhone 11 64gb Black 4G+ Smartphone 564Euro


</figcaption></b>

</figure>
<img alt="Qries" src="https://cdn.plaisio.gr/mms/Product-Images/PlaisioGr/3/3/0/8/4/6/4/3308464.jpg?h=800&w=800&hash=E438B04D691B6A10576AE346CE452657BFF56845" width="100" height="170" style="height: 249px; ">

</div>
</center>
<b>
<table class="table table-bordered attribute"><tbody><tr style="">
<td style="font-size: 12px !important;width: 250px;">Brand</td>
<td style="font-size: 12px !important;width: 250px;">Apple</td></tr><tr style="">
<td style="font-size: 12px !important;width: 250px;">Number of SIM</td>
<td style="font-size: 12px !important;width: 250px;">Single</td></tr><tr style="">
<td style="font-size: 12px !important;width: 250px;">SIM Type</td>
<td style="font-size: 12px !important;width: 250px;">nano‑SIM and eSIM</td></tr><tr style="">
<td style="font-size: 12px !important;width: 250px;">Chipset</td>
<td style="font-size: 12px !important;width: 250px;">A13 Bionic</td></tr><tr style="">
<td style="font-size: 12px !important;width: 250px;">Width</td>
<td style="font-size: 12px !important;width: 250px;">71.4mm</td></tr><tr style="">
<td style="font-size: 12px !important;width: 250px;">Height</td>
<td style="font-size: 12px !important;width: 250px;">144mm</td></tr><tr style="">
<td style="font-size: 12px !important;width: 250px;">Weight</td>
<td style="font-size: 12px !important;width: 250px;">188g</td></tr><tr style=""><td style="font-size: 12px !important;width: 250px;">Battery</td>
<td style="font-size: 12px !important;width: 250px;">Lasts up to 4 hours longer than iPhone XSVideo playback:
Up to 18 hoursVideo playback (streamed):
Up to 11 hoursAudio playback:
Up to 65 hours18W adapter included</td></tr><tr style="">
<td style="font-size: 12px !important;width: 250px;">Sensors</td>
<td style="font-size: 12px !important;width: 250px;">True Tone display
Wide color display (P3)
Haptic Touch
800 nits max brightness (typical); 1200 nits max brightness (HDR)
Fingerprint-resistant oleophobic coating
Support for display of multiple languages and characters simultaneously</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Capacity</td><td style="
font-size: 12px !important;width: 250px;">64GB</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Operating System</td><td style="
font-size: 12px !important;width: 250px;">ios 13</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">External Memory</td><td style="
font-size: 12px !important;width: 250px;">No</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Screen Type</td><td style="
font-size: 12px !important;width: 250px;">Super Retina XDR display</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Resolution</td><td style="
font-size: 12px !important;width: 250px;">1792 x 828 pixels</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Pixel Density</td><td style="
font-size: 12px !important;width: 250px;">458</td></tr></tbody></table>
<td style="display: -webkit-box;"><table class="table table-bordered attribute"><tbody><tr style=""><td style="
font-size: 12px !important;width: 250px;">Touch</td><td style="
font-size: 12px !important;width: 250px;">Multi‑Touch display</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Protection</td><td style="
font-size: 12px !important;width: 250px;">Splash, Water, and Dust Resistant</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Screen Size</td><td style="
font-size: 12px !important;width: 250px;">5.8 Inch</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Wireless</td><td style="
font-size: 12px !important;width: 250px;">4G/3G/Wireless/Bluetooth/NFC</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Bluetooth Version</td><td style="
font-size: 12px !important;width: 250px;">5.0</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Network Type</td><td style="
font-size: 12px !important;width: 250px;">FDD‑LTE (Bands 1, 2, 3, 4, 5, 7, 8, 11, 12, 13, 17, 18, 19, 20, 21, 25, 26, 28, 29, 30, 32, 66)
TD‑LTE (Bands 34, 38, 39, 40, 41, 42, 46, 48)
UMTS/HSPA+/DC‑HSDPA (850, 900, 1700/2100, 1900, 2100 MHz)
GSM/EDGE (850, 900, 1800, 1900 MHz)</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">GPS</td><td style="
font-size: 12px !important;width: 250px;">Yes, with GPS/GNSS</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">WiFi</td><td style="
font-size: 12px !important;width: 250px;">Wi-Fi 802.11 a/b/g/n/ac, dual-band, hotspot</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Facetime</td><td style="
font-size: 12px !important;width: 250px;">Yes</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Flash</td><td style="
font-size: 12px !important;width: 250px;">Yes</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Main Camera</td><td style="
font-size: 12px !important;width: 250px;">12 MP + 12 MP /12 MP</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Video Recording</td><td style="
font-size: 12px !important;width: 250px;">4K video recording at 24 fps, 30 fps, or 60 fps
1080p HD video recording at 30 fps or 60 fps
720p HD video recording at 30 fps</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Selfie Camera</td><td style="
font-size: 12px !important;width: 250px;">12 MP</td></tr><tr style=""><td style="
font-size: 12px !important;width: 250px;">Fast Charging</td><td style="
font-size: 12px !important;width: 250px;">Yes</td></tr></tbody></table></td>

</b>

</html>
