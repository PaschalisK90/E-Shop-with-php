<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>



<html>
<head>
<meta charset="ISO-8859-1">
<title>ProductsOrder</title>
<link rel="stylesheet" type="text/css" href="ProductOrder.css"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<h4 align="right">
    <h4 align="right">    <button type="button" class="btn btn-default btn-sm">
          <span class="glyphicon glyphicon-log-out"></span><a href="home.php"> Log out</a>
        </button></h4>
        <br>
<div class="container">
	<table id="cart" class="table table-hover table-condensed">
    				<thead>
						<tr>
							<th style="width:50%">Product</th>
							<th style="width:10%">Price</th>
							<th  style="width:8%">Quantity</th>
							<th style="width:22%" class="text-center">Subtotal</th>
							<th style="width:10%"></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td data-th="Product">
								<div class="row">
									<div class="col-sm-2 hidden-xs"><img src="http://placehold.it/100x100" alt="..." class="img-responsive"/></div>
									<div class="col-sm-10">
										<h4 class="nomargin" id="name" value=" ">


										</h4>
										<p>Apple iPhone 11 64gb Black 4G+ Smartphone</p>
									</div>
								</div>
							</td>
								
							<td data-th="Price">564</td>
							<td data-th="Quantity">
							
							
							  
						
		
								<input type="number" min=1 name="quantity" id="field1" value="1" >
								
							</td>
							
									
							
							
			
							
							
							<td data-th="Subtotal" class="text-center" >
							
							
							
						  <input type="text" id="field2" value="564" >
							 
                                </td>
							<td class="actions" data-th=" ">
							
							
														
														
							</td>
						</tr>
					</tbody>
					<tfoot>
						<tr class="visible-xs">
							<td class="text-center"><strong> </strong></td>
						</tr>
						<tr>
							<td><a href="Smartphones.php" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a></td>
							<td colspan="2" class="hidden-xs"></td>
							
							
							<td class="hidden-xs text-center"><strong></strong></td>
						
							
							
						</tr>
					</tfoot>
				</table>
</div>


<center><button  style="color:white;background-color:green;" onclick="window.location.href ='CompleteOrder.php'";>Complete my Order</button></center>





</body>
</html>
