<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Home</title>
<link rel="stylesheet" type="text/css" href="StyleHome.css"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<b><h3><marquee behavior="scroll" direction="left">Profit from our outstanding offers of this month!!!<i style="color:red;">Xiaomi Redmi Note 7 (128GB)  160Euro</i>, <i style="color:green;">Huawei P30 Lite Dual (128GB) 185Euro</i> only for a few days availiable in our store.   </marquee></h3></b>
<div class="topnav">

<a href="Contact.php">Contact Us</a>
<a href="ProductsPage.php">Home</a>

</div>
<div>
<button onclick="window.location.href ='Register.php';" value="Registration">Register</button>
<button onclick="window.location.href ='Login.php';" value="Registration">Login</button>

  
</div>
<center><h1 style="background-color:yellow;">E-SHOP PAGE</h1></center>
<br><br><br><br>

<h1>Please you must create an Account or log in before you continue.</h1>	<img alt="Qries" src="mobile-phone-world-map-38259051.jpg" style="height: 249px; ">
</body>
</html>
